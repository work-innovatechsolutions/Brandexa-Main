<?php 
/*
Plugin Name:  Artistics Theme Addons
Plugin URI:   https://awaikenthemes.com
Description:  This plugin is intended for use with the artistics theme.
Version:      1.0.2
Author:       Awaiken Themes
Author URI:   https://awaikenthemes.com
License:      GNU General Public License v3 or later.
License URI:  https://www.gnu.org/licenses/gpl-3.0.html
Text Domain:  artistics-themes-addons
Domain Path:  /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'ARTISTIC_ADDONS_URL', plugins_url( '/', __FILE__ ) );
define( 'ARTISTIC_ADDONS_PATH', plugin_dir_path( __FILE__ ) );
define( 'ARTISTIC_PLUGIN_VERSION', '1.0.2' );

// Load translation.
add_action( 'init', 'artistic_i18n' );

/**
 * Load the plugin text domain for translation.
 *
 * @since    1.0.0
 */
function artistic_i18n() {
	load_plugin_textdomain( 'artistic-themes-addons' );
}

/* Allow SVG upload */
add_filter( 'wp_check_filetype_and_ext', function( $data, $file, $filename, $mimes ) {

  $filetype = wp_check_filetype( $filename, $mimes );

  return [
      'ext' => $filetype['ext'],
      'type' => $filetype['type'],
      'proper_filename' => $data['proper_filename']
  ];

}, 10, 4 );

function artistic_allow_svg_upload( $mimes ) {
  $mimes['svg'] = 'image/svg+xml';
  $mimes['svgz'] = 'image/svg+xml';
  return $mimes;
}
add_filter( 'upload_mimes', 'artistic_allow_svg_upload' );

require ARTISTIC_ADDONS_PATH . 'includes/secondary-image.php';


/*
* Project CPT
*/
if(!class_exists('Awaiken_Portfolio')) { 
	class Awaiken_Portfolio {

		const CPT_SLUG = 'awaiken-project';
		const TAXONOMY_CATEGORY_SLUG = 'awaiken-project-category';

		public function register_data() {

			$labels = [
				'name' => esc_html_x( 'Projects', 'Projects', 'artistic-themes-addons' ),
				'singular_name' => esc_html_x( 'Project', 'Project', 'artistic-themes-addons' ),
				'menu_name' => esc_html_x( 'Projects', 'Projects', 'artistic-themes-addons' ),
				'name_admin_bar' => esc_html__( 'Project Item', 'artistic-themes-addons' ),
				'archives' => esc_html__( 'Project Item Archives', 'artistic-themes-addons' ),
				'parent_item_colon' => esc_html__( 'Parent Item:', 'artistic-themes-addons' ),
				'all_items' => esc_html__( 'All Items', 'artistic-themes-addons' ),
				'add_new_item' => esc_html__( 'Add New Project', 'artistic-themes-addons' ),
				'add_new' => esc_html__( 'Add New', 'artistic-themes-addons' ),
				'new_item' => esc_html__( 'New Project', 'artistic-themes-addons' ),
				'edit_item' => esc_html__( 'Edit Project', 'artistic-themes-addons' ),
				'update_item' => esc_html__( 'Update Project', 'artistic-themes-addons' ),
				'view_item' => esc_html__( 'View Project', 'artistic-themes-addons' ),
				'search_items' => esc_html__( 'Search Projects', 'artistic-themes-addons' ),
				'not_found' => esc_html__( 'Not found', 'artistic-themes-addons' ),
				'not_found_in_trash' => esc_html__( 'Not found in Trash', 'artistic-themes-addons' ),
				'featured_image' => esc_html__( 'Featured Image', 'artistic-themes-addons' ),
				'set_featured_image' => esc_html__( 'Set featured image', 'artistic-themes-addons' ),
				'remove_featured_image' => esc_html__( 'Remove featured image', 'artistic-themes-addons' ),
				'use_featured_image' => esc_html__( 'Use as featured image', 'artistic-themes-addons' ),
				'insert_into_item' => esc_html__( 'Insert into Project', 'artistic-themes-addons' ),
				'uploaded_to_this_item' => esc_html__( 'Uploaded to this Project', 'artistic-themes-addons' ),
				'items_list' => esc_html__( 'Items list', 'artistic-themes-addons' ),
				'items_list_navigation' => esc_html__( 'Items list navigation', 'artistic-themes-addons' ),
				'filter_items_list' => esc_html__( 'Filter items list', 'artistic-themes-addons' ),
			];

			$portfolio_slug = apply_filters( 'awaiken_portfolio_slug', 'projects' );

			$rewrite = [
				'slug' => $portfolio_slug,
				'with_front' => false,
			];

			$args = [
				'labels' => $labels,
				'public' => true,
				'menu_position' => 25,
				'menu_icon' => 'dashicons-format-image',
				'capability_type' => 'post',
				'supports' => [ 'title', 'editor', 'thumbnail', 'author', 'excerpt', 'comments', 'revisions', 'page-attributes', 'custom-fields', 'elementor' ],
				'has_archive' => true,
				'rewrite' => $rewrite,
			];

			register_post_type( self::CPT_SLUG, $args );

			// Categories
			$portfolio_category_slug = apply_filters( 'awaiken_portfolio_category_slug', 'project-category' );

			$rewrite = [
				'slug' => $portfolio_category_slug,
				'with_front' => false,
			];

			$args = [
				'hierarchical' => true,
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'show_admin_column' => true,
				'labels' => $labels,
				'rewrite' => $rewrite,
				'public' => true,
				'labels' => [
					'name' => esc_html_x( 'Categories', 'Project', 'artistic-themes-addons' ),
					'singular_name' => esc_html_x( 'Category', 'Project', 'artistic-themes-addons' ),
					'all_items' => esc_html_x( 'All Categories', 'Project', 'artistic-themes-addons' ),
				],
			];
			register_taxonomy( self::TAXONOMY_CATEGORY_SLUG, self::CPT_SLUG, $args );
		}

		public function __construct() {
			add_action( 'init', [ $this, 'register_data' ], 1 );
		}
	}
	/**
	 * initialize 
	 */
	$Awaiken_Portfolio = new Awaiken_Portfolio();
}

function artistic_add_body_class_meta_box() {
    $screens = ['page', 'awaiken-project']; 
    foreach ($screens as $screen) {
        add_meta_box(
            'artistic_body_class_meta_box',
            'Custom Body Class',
            'artistic_body_class_meta_box_callback',
            $screen,
            'side'
        );
    }
}
add_action('add_meta_boxes', 'artistic_add_body_class_meta_box');


function artistic_body_class_meta_box_callback($post) {
    $value = get_post_meta($post->ID, '_artistics_body_class', true);
    echo '<label for="artistics_body_class">'.esc_html__( 'Class Name:', 'artistics' ).'</label>';
    echo '<input type="text" id="artistics_body_class" name="artistics_body_class" value="' . esc_attr($value) . '" style="width:100%;" />';
	echo '<p>'.esc_html__( 'Multiple class names should be separated by a space.', 'artistics' ).'</p>';
}


function artistic_save_body_class_meta_box($post_id) {
    if (array_key_exists('artistics_body_class', $_POST)) {
        $input = trim($_POST['artistics_body_class']);

        if ($input === '') {
            update_post_meta($post_id, '_artistics_body_class', '');
        } else {
            // Explode by spaces
            $classes = explode(' ', $input);

            // Sanitize each class
            $classes = array_map('sanitize_html_class', $classes);

            // Remove empty values
            $classes = array_filter($classes);

            // Rebuild the string
            $class_string = implode(' ', $classes);

            update_post_meta($post_id, '_artistics_body_class', $class_string);
        }
    }
}
add_action('save_post', 'artistic_save_body_class_meta_box');